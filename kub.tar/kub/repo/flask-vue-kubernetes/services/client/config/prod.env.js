'use strict'
module.exports = {
  NODE_ENV: '"production"',
  ROOT_API: JSON.stringify(process.env.ROOT_API)
}
